import java.util.ArrayList;
import java.util.Iterator;


public class Habitacion {
	
	private int id;
	private String tipo;
	private ArrayList<String> caracteristicas; //formato balcon, vista, integrada, cama1, cama2, etc.
	private float tarifa;
	private boolean ocupado;
	

	/*public Habitacion(int parseInt, String string, Object object, float parseFloat, boolean parseBoolean) {
		// TODO Auto-generated constructor stub
	}*/

	public Habitacion(int id, String tipo, ArrayList<String> caracteristicas, float tarifa,
			boolean ocupado) {
		super();
		this.id = id;
		this.tipo = tipo;
		this.caracteristicas = caracteristicas;
		this.tarifa = tarifa;
		this.ocupado = ocupado;
	}

	
	public void setTarifa() {
		Iterator<String> itr = this.caracteristicas.iterator();
		while (itr.hasNext()) {
			Object element = itr.next();
			if (this.tipo.equals("estandar")) {
				this.tarifa += 2000;
			} else { if (this.tipo.equals("suite")) {
				this.tarifa += 5000;
			} else { if (this.tipo.equals("doble")) {
				this.tarifa += 7000;
			} } }
			if (element.equals("balcon")) {
				this.tarifa += 1000;
			}
			if (element.equals("vista")) {
				this.tarifa += 1500;
			}
			if (element.equals("integrada")) {
				this.tarifa += 2500;
			}
			if (element.equals("king")) {
				this.tarifa += 300;
			}
			if (element.equals("queen")) {
				this.tarifa += 200;
			}
			if (element.equals("doble")) {
				this.tarifa += 100;
			}
			if (element.equals("semidoble")) {
				this.tarifa += 50;
			}
			if (element.equals("sencillo")) {
				this.tarifa += 20;
			}
		}
	}
	
	public int getCapacidad(Habitacion room) {
		Iterator<String> itr = this.caracteristicas.iterator();
		int capacidad = 0;
		while (itr.hasNext()) {
			Object element = itr.next();
			if (element.equals("king")) {
				capacidad += 5;
			}
			if (element.equals("queen")) {
				capacidad += 4;
			}
			if (element.equals("doble")) {
				capacidad += 3;
			}
			if (element.equals("semidoble")) {
				capacidad += 2;
			}
			if (element.equals("sencillo")) {
				capacidad += 1;
			}
		}
		return capacidad;
	}
	
	public Boolean getIfCamasKids(Habitacion room) {
		Iterator<String> itr = this.caracteristicas.iterator();
		Boolean camasKids = false;
		while (itr.hasNext()) {
			Object element = itr.next();
			if (element.equals("sencillo")) {
				camasKids = true;
			}
		}
		return camasKids;
	}

	private void updateTarifa(Habitacion room) 
	{
		
	}
	
	private void addCaracteristicas(Habitacion room, ArrayList<String> caracteristicas)
	{
		
	}
	
	private void removeCaracteristicas(Habitacion room, ArrayList<String> caracteristicas)
	{
		
	}
	
	public boolean isOcupado(Habitacion room)
	{
		return false;
	}
}
