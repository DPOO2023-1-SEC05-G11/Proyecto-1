
public class Admin extends Usuario
{
	public Admin() {
	}
}