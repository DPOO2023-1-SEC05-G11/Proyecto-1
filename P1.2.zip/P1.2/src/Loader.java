import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public interface Loader {
	
	private void cargarHabitaciones() throws IOException
	{
		File habitaciones = new File("data/x.txt");
	}
	
	private void addHabitacion(Habitacion room)
	{
		
	}
	
	private void updateHabitaciones() throws IOException
	{
		File habitaciones = new File("data/x.txt");
	}
	
	private void removeHabitacion(Habitacion room)
	{
		
	}
	
	private void buscarHabitacion(Habitacion room)
	{
		
	}
	
	private void addServicio(Servicio service)
	{
		
	}
	
	private void updateServicio(Servicio service)
	{
		
	}
	
	private void removeServicio(Servicio service)
	{
		
	}
	
	private void buscarServicio(Servicio service)
	{
		
	}
	
	private void addTarifa(Tarifa fee)
	{
		
	}
	
	private void updateTarifa(Tarifa service)
	{
		
	}
	
	private void addMenu(Menu menu)
	{
		
	}
	
	private void updateMenu(Menu service)
	{
		
	}
	
	private void removeMenu(Menu service)
	{
		
	}
	
	private void buscarMenu(Menu service)
	{
		
	}
	
	public default void createReserva(Reserva reserva) 
	{
		
	}
	
	public default void mostrarReserva(Reserva reserva) 
	{
		
	}
	
	public static void cargarInformacionHotel(File archivoHabitaciones, File archivoMenu) throws IOException 
	{
		ArrayList<Habitacion> habitaciones = cargarHabitaciones(archivoHabitaciones);
		ArrayList<Producto> productosMenu = cargarMenu(archivoMenu);
		//ArrayList<Combo> combos = cargarCombos(archivoCombos);
	}
	
	private static ArrayList<Habitacion> cargarHabitaciones(File archivoIngredientes) throws FileNotFoundException, IOException 
	{
		try (BufferedReader br = new BufferedReader(new FileReader(archivoIngredientes)))
		{
			String linea;
			ArrayList<Habitacion> habitacion = new ArrayList<Habitacion>();
			while ((linea = br.readLine()) != null) 
			{
				String[] split = linea.split(";");
				Habitacion habitaciones = new Habitacion(Integer.parseInt(split[0]), split[1], null, Float.parseFloat(split[3]), Boolean.parseBoolean(split[4]));
				habitacion.add(habitaciones);
			}
			return habitacion;
		}
	}
	
	private static ArrayList<Producto> cargarMenu(File archivoMenu) throws IOException 
	{
		try (BufferedReader br = new BufferedReader(new FileReader(archivoMenu)))
		{
		String linea;
		ArrayList<Producto> productos = new ArrayList<Producto>();
		while ((linea = br.readLine()) != null) 
		{
			String[] split = linea.split(";");
			Producto productoMenu = new Producto(split[0], Float.parseFloat(split[1]), split[2], Integer.parseInt(split[3]), Boolean.parseBoolean(split[4]));			productos.add(productoMenu);
		}
		return productos;
		}
	}
}
