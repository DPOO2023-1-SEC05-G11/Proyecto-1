import java.util.Iterator;

import uniandes.dpoo.taller2.modelo.Ingrediente;

public class Consumo {

	private Servicio servicioConsumido;
	private int cantidadConsumida;
	
	public void addConsumo(Consumo consumed)
	{
		
	}
	
	public void removeConsumo(Consumo consumed)
	{
		
	}
	
	public float calcularTotal(Consumo consumed)
	{
			/*
			String eachAdded = "";
			String eachRemoved = "";
				if (this.adicion.size() > 0 || this.removed.size() > 0) {
				Iterator<Ingrediente> itr = adicion.iterator();
				Iterator<Ingrediente> itr2 = removed.iterator();
				while (itr.hasNext()) {
					Object element = itr.next();
					eachAdded += "adicionado de " + this.adicion.get((int) element).getNombre();
					while (itr2.hasNext()) {
						Object element2 = itr2.next();
						eachRemoved += "sin " + this.removed.get((int) element2).getNombre();
					}
				}
				}
			return this.base.getNombre() + eachAdded + eachRemoved;*/
		return (float) 0.0;
	}
	
	public boolean pagarYa(Consumo consumed)
	{
		return false;
	}
}
