
public class Menu extends Producto {
	
	public Menu(String nombre, float precio, String tipo, int available, boolean paraHabitacion) {
		super(nombre, precio, tipo, available, paraHabitacion);
		// TODO Auto-generated constructor stub
	}

	public String getNombre(Producto prod)
	{
		return "";
	}
	
	public String getTipo(Producto prod)
	{
		return "";
	}
	
	public float getPrecio(Producto prod)
	{
		return (float) 0.0;
	}
}
