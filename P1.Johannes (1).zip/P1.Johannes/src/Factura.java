import java.util.*;

public class Factura {
	
	public float calcularTotalConsumo(ArrayList<Consumo> consumed)
	{
		return (float) 0.0;
	}
	
	public float calcularTotalEstadia(Reserva booked)
	{
		return (float) 0.0;
	}
}
