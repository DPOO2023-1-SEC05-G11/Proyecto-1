
public class Consumo {

	private Servicio servicioConsumido;
	private int cantidadConsumida;
	
	public void addConsumo(Consumo consumed)
	{
		
	}
	
	public void removeConsumo(Consumo consumed)
	{
		
	}
	
	public float calcularTotal(Consumo consumed)
	{
		return (float) 0.0;
	}
	
	public boolean pagarYa(Consumo consumed)
	{
		return false;
	}
}
