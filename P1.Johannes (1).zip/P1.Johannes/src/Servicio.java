
public class Servicio {
	
	private String nombre;
	private String descripcion;
	private float tarifa;
	
	public String getNombre() {
		return nombre;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public float getTarifa() {
		return tarifa;
	}
	
}
