package Modelo;

import java.util.HashMap;

public class Spa extends Servicio{
	
	public Spa(HashMap<String, Integer> map)
	{
		super(map);
	}

}
