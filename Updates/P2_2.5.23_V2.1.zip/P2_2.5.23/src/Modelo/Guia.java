package Modelo;

import java.util.HashMap;

public class Guia extends Servicio{
	
	public Guia(HashMap<String, Integer> map)
	{
		super(map);
	}

}
