package Modelo;

public class Usuario {

}
