package Modelo;

import java.util.HashMap;

public class Restaurante extends Servicio{
	
	private Restaurante(HashMap<String, Integer> map)
	{
		super(map);
	}
	
	//call getInstance(map) to use
	


}
